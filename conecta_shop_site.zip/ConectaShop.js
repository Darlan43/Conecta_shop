
    import { Card, CardContent } from "@/components/ui/card";
    import { Button } from "@/components/ui/button";
    import { Input } from "@/components/ui/input";
    import { Instagram, Phone } from "lucide-react";
    
    export default function ConectaShop() {
      return (
        <div className="p-4 md:p-8 max-w-5xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-2">Conecta Shop</h1>
          <p className="text-center text-lg mb-6 text-muted-foreground">
            Conectando você ao que importa!
          </p>
    
          <section className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-10">
            { [
                { title: "Fones de ouvido", desc: "Bluetooth e com fio, com alta qualidade de som.", img: "https://images.unsplash.com/photo-1585386959984-a4155224a1b5" },
                { title: "Carregadores", desc: "Turbo e por indução, para carregamento rápido.", img: "https://images.unsplash.com/photo-1603787081207-0e6b53be7c29" },
                { title: "Capinhas", desc: "Estilosas e resistentes para vários modelos.", img: "https://images.unsplash.com/photo-1611186871348-bb52a841c8da" },
                { title: "Adaptadores Bluetooth", desc: "Conecte seus dispositivos com facilidade.", img: "https://images.unsplash.com/photo-1587829741301-dc798b83add3" },
              ].map((product, index) => (
                <Card key={index} className="rounded-2xl overflow-hidden shadow-md">
                  <img src={product.img} alt={product.title} className="w-full h-48 object-cover" />
                  <CardContent className="p-4">
                    <h2 className="text-xl font-semibold mb-1">{product.title}</h2>
                    <p className="text-sm text-muted-foreground mb-2">{product.desc}</p>
                    <Button variant="outline">Saiba mais</Button>
                  </CardContent>
                </Card>
              )) }
          </section>
    
          <section className="bg-gray-100 p-6 rounded-2xl shadow-sm mb-10">
            <h3 className="text-2xl font-bold mb-2">Por que comprar na Conecta Shop?</h3>
            <ul className="list-disc list-inside text-muted-foreground">
              <li>Produtos selecionados com qualidade</li>
              <li>Ótimos preços e promoções</li>
              <li>Atendimento rápido via WhatsApp</li>
              <li>Entrega rápida para todo o Brasil</li>
            </ul>
          </section>
    
          <section className="bg-white p-6 rounded-2xl shadow-sm mb-10">
            <h3 className="text-2xl font-bold mb-4">Pagamento e Entrega</h3>
            <p className="text-muted-foreground">
              Aceitamos <strong>Pix</strong> e <strong>cartão de crédito (parcelado)</strong>. Entregamos em todo o Brasil com frete acessível.
            </p>
          </section>
    
          <section className="bg-gray-50 p-6 rounded-2xl shadow-sm text-center">
            <h3 className="text-2xl font-bold mb-4">Fale com a gente</h3>
            <p className="mb-2 flex justify-center items-center gap-2">
              <Phone size={18} /> WhatsApp: (seu número)
            </p>
            <p className="mb-2 flex justify-center items-center gap-2">
              <Instagram size={18} /> Instagram: @conectashop
            </p>
            <p className="text-muted-foreground">Email: contato@conectashop.com</p>
          </section>
        </div>
      );
    }
    